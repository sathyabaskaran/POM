package com.selenium.testng.base;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import com.selenium.api.base.SeleniumBase;

public class ProjectSpecificMethods extends SeleniumBase{
	
	@BeforeMethod
	public void beforeMethod() {
		driver = startApp("http://leaftaps.com/opentaps");
		node = test.createNode(testName);

	}
	
	@AfterMethod
	public void afterMethod() {
		closeApp();

	}

}
