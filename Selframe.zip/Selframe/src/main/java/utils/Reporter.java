package utils;

import java.io.IOException;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.MediaEntityModelProvider;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public abstract class Reporter  {

	public ExtentHtmlReporter reporter;
	public ExtentReports extent;
	public String testName, description,author,category;
	public ExtentTest test,node;
	
	@BeforeSuite
	public void startReport() {
		reporter = new ExtentHtmlReporter("./Report/result.html");
		reporter.setAppendExisting(true);
		extent = new ExtentReports();
		extent.attachReporter(reporter);
	}
	
	@BeforeClass
	public void report() {
		test = extent.createTest(testName, description);
		test.assignAuthor(author);
		test.assignCategory(category);

	}
	
	public void reportStep(String desc,String status){
		long snapnumber = takesnapshot();
		MediaEntityModelProvider img = null;
		try {
			
			img = MediaEntityBuilder.createScreenCaptureFromPath("./Report/images/"+snapnumber+".jpg").build();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(status.equalsIgnoreCase("pass"))
		{
		node.pass(desc, img);
		}
		if(status.equalsIgnoreCase("fail"))
		{
			node.fail(desc, img);
		}
	}

	public abstract long takesnapshot();
	
	@AfterSuite
	public void closeReport() {
		extent.flush();

	}
}
