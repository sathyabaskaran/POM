package tests;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.selenium.testng.base.ProjectSpecificMethods;

import Pages.LoginPage;

public class LoginApplication extends ProjectSpecificMethods{
	
	@BeforeTest
	private void setTestDetails() {
		testName = "Login my application";
		description = "login application with valid credentials";
		author = "sathya";
		category = "smoke testing";

	}

	@Test
	public void testcase() {
		new LoginPage(driver,node).enterUserName().enterPassword().clickSubmit();

	}
}
