package Pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.selenium.testng.base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {
	
	public  LoginPage(RemoteWebDriver driver, ExtentTest node) {
		this.driver = driver;
		this.node = node;

	}
	
	
	public LoginPage enterUserName() {
		driver.findElement(By.id("username")).sendKeys("DemoSalesManager");
		reportStep("Username entered", "pass");
		return this;

	}
	
	public LoginPage enterPassword() {
		driver.findElement(By.id("password")).sendKeys("crmsfa");
		reportStep("Password entered", "pass");
		return this;

	}

	public LoginPage clickSubmit() {
		driver.findElement(By.className("decorativeSubmit")).click();
		reportStep("submit clicked", "pass");
		return this;

	}
}
